import json
import boto3
from datetime import datetime
from io import StringIO


def lambda_handler(event, context):
    # TODO implement
    # All log events in encrypted format and deciphering it 
    outEvent = event
    millisTime = int((datetime.utcnow() - datetime(1970, 1, 1)).total_seconds() * 1000)
    # outEvent = zlib.decompress(base64.b64decode(outEvent), 16 + zlib.MAX_WBITS).decode('utf-8')
    
    # --------------------
    # Putting log events in a log group name - GuardDutyLogs
    client = boto3.client('logs')
    
    now = datetime.now()
    current_year = str(now.year)
    current_month = str(now.month)
    current_day = str(now.day)
    
    # -----------------------
    # Auto generating the log stream name where Findings needs to be logged based on the date
    # -----------------------
    logStreamName_gen=current_year+'-'+current_month+'-'+current_day
    
    # -----------------------
    # Get the existing list of log stream names in the LogGroup
    # -----------------------
    response = client.describe_log_streams(
                    logGroupName='GuardDutyLogs'
    )
    # print (response1)
    # print (response1['logStreams'][0]['uploadSequenceToken'])
    # stoken = response1['logStreams'][0]['uploadSequenceToken']
    
    # -----------------------
    # Validate if the LogStream already exists or needs to be newly created
    # -----------------------
    a='0'
    for logstream in response['logStreams']:
          if logStreamName_gen==logstream['logStreamName']:
            a='1'
            break
        
    #--------------------------------------------------------
    # If it does not exist, create a new LogStream
    #--------------------------------------------------------
    print("The Value of a is::", a)
    print("The data type of a is::",type(a))
    if a=='0':
        response1 = client.create_log_stream(
            logGroupName='GuardDutyLogs',
            logStreamName=logStreamName_gen
        )
    else:
        response1='null'
        print(logStreamName_gen)
        
    #--------------------------------------------------------------------------
    # Get the Next Sequence number to enable the Put operation into the LogStream
    #---------------------------------------------------------------------------
    response2 = client.describe_log_streams(
          logGroupName='GuardDutyLogs',
          logStreamNamePrefix=logStreamName_gen
          )
    print ("resp2: ", response2)
    response2_json=json.dumps(response2)
    print ("resp2_json: ", response2_json)
    b='0'
    if 'uploadSequenceToken' not in response2_json:
        b='1'
    else:
        b='0'
        
    #--------------------------------------------------------------------------------------------
    # If Sequence Number exists, get the Sequence Number and then Put the data into the LogStream
    #--------------------------------------------------------------------------------------------
    if b=='0':
        uploadSequenceToken=response2['logStreams'][0]['uploadSequenceToken']
        response3=client.put_log_events(
            logGroupName='GuardDutyLogs',
            logStreamName=logStreamName_gen,
            logEvents=[
              {
                  'timestamp': millisTime,
                  'message': str(outEvent)

              },
              ],
          sequenceToken=uploadSequenceToken
          )
        print("resp3: ",response3)
    #--------------------------------------------------------------------------------------------------------------------
    # If Sequence Number does not exist, just Put the data into the LogStream without the Sequence Number value in payload
    #---------------------------------------------------------------------------------------------------------------------
    else:
        response3=client.put_log_events(
            logGroupName='GuardDutyLogs',
            logStreamName=logStreamName_gen,
            logEvents=[
              {
                  'timestamp': millisTime,
                  'message': str(outEvent)

              },
              ]
            )
        print("resp3: ",response3)